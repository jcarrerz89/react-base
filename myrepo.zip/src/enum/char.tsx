enum Characters  {
    EMPTY = ''
}

export default Characters;